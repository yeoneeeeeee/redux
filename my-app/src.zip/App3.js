import './App.css';

import {Pure, Shallow} from './05_PureComponent';

import { TestUseState, TestUseEffect, TestUseCallback } from './06_FunctionComponent';

import Fragements from './07_Fragements';

import Spread from './08_SpreadOperator';

function App3(){
    return(
        // <Pure/>
        // <Shallow/>
        // <TestUseState/>
        // <TestUseEffect/>
        // <TestUseCallback/>
        // <table>
        //     <thead>
        //         <tr>
        //             <Fragements/>
        //         </tr>
        //     </thead>
        // </table>
        <Spread/>
    )
}

export default App3;