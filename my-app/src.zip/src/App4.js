import './App.css'

import {ContextApi} from './09_Context';

import RouterComponent from './10_RouterComponent';

import ReactRef from './11_Ref';

import Hoc from './15_Hoc';

function App4(){
    return(
        // <ContextApi/>
        // <RouterComponent/>
        // <ReactRef/>
        <Hoc/>
    )
}

export default App4;