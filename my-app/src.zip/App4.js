import './App.css'

import { ContextApi } from './09_Context';

function App4(){
    return (
        <ContextApi/>
    )
}

export default App4;