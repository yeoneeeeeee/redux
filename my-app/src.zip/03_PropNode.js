import { Component } from 'react';

class PropNode extends Component{

    render(){
        return(
            <div style={{padding:"0px"}}>
                {this.props.children} 
                {/* 전달받은 코드를 화면에 뿌려주는 역할하는 코드 */}
            </div>
        )
    }
}


export default PropNode;