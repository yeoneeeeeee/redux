import Children2 from './ContextChildren2';

function Children(){
    return <Children2/>
}
export default Children;